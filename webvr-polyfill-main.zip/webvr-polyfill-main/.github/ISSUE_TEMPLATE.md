##### Description:

Please describe your issue or feature request in detail.
Code and screenshots will help us diagnose the issue.

##### Additional Information:

* webvr-polyfill version:
* Browser name/version/release channel:
* Operating System:
